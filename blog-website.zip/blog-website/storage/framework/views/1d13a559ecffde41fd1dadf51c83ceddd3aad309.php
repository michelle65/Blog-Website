<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <p class="quote">The beautiful Laravel</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <h1 class="post-title">Learning Laravel
           <p>This blog will get you right...</p>
           <p><a href="<?php echo e(route('blog.post',['id'=>1])); ?>">Read more...</a></p>
            </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <h1 class="post-title">Learning Laravel
                <p>This blog will get you right...</p>
                <p><a href="<?php echo e(route('blog.post',['id'=>2])); ?>">Read more...</a></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <h1 class="post-title">Learning Laravel
                <p>This blog will get you right...</p>
                <p><a href="<?php echo e(route('blog.post',['id'=>3])); ?>">Read more...</a></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mihaela\Desktop\Blog Website\blog-website\resources\views/blog/index.blade.php ENDPATH**/ ?>