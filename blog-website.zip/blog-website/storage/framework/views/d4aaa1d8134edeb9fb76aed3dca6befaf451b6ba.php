
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12">
    <p class="quote"><?php echo e($post['title']); ?></p>
</div>
<div class="row">
    <div class="col-md-12">
        <p><?php echo e($post['content']); ?></p>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mihaela\Desktop\Blog Website\blog-website\resources\views/blog/post.blade.php ENDPATH**/ ?>