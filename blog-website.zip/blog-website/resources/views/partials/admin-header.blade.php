<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="">Laravel Guide</a>
            <ul class="nav navbar-nav">
                <li class="active"><a href="">Posts</a></li>
            </ul>
        </div>
    </div>
</nav>